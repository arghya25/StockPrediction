const API_KEY = "614041ff36fb4ce7afa589e33fbc9c5d"
const url = "https://newsapi.org/v2/everything?q="


async function fetchData(query){
    const res = await fetch(`${url}${query}&apiKey=${API_KEY}`)
    const data = await res.json()
    return data
}

fetchData("Buisness").then(data => renderMain(data.articles))

//render news
function renderMain(arr){
    let mainHTML =''
    for(let i = 0 ; i < arr.length ;i++){
        mainHTML +=`<div class="card">
                       <a href=${arr[i].url}>
                       <img src=${arr[i].urlToImage} />
                       <h4>${arr[i].title}</h4>
                       <div class="publishbyDate">
                           <p>${arr[i].source.name}</p>
                           <span>•</span>
                           <P>${new Date(arr[i].publishedAt).toLocaleDateString()}</P>
                       </div>    
                       <div class="desc">
                            ${arr[i].description}
                       </div>
                       </a>
                    </div>`
    }
    document.querySelector("main").innerHTML = mainHTML
}

const searchBtn = document.getElementById("searchForm")
const searchInput = document.getElementById("searchInput")

searchBtn.addEventListener("submit",async(e)=>{
    e.preventDefault()
    console.log(searchInput.value())

    const data = await fetchData(searchInput.value)
    renderMain(data.articles)
})

function InputSearch(querry){

}



