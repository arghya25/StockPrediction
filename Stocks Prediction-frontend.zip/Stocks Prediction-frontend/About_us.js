function myFunction() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("myBtn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.innerHTML = "Read less";
        moreText.style.display = "inline";
    }
}

function myFunctionn() {
    var dotss = document.getElementById("dotss");
    var moreeText = document.getElementById("moree");
    var btnnText = document.getElementById("myBtnn");

    if (dotss.style.display === "none") {
        dotss.style.display = "inline";
        btnnText.innerHTML = "Read more";
        moreeText.style.display = "none";
    } else {
        dotss.style.display = "none";
        btnnText.innerHTML = "Read less";
        moreeText.style.display = "inline";
    }
}

function myFunctionnn() {
    var dotsss = document.getElementById("dotsss");
    var moreeeText = document.getElementById("moreee");
    var btnnnText = document.getElementById("myBtnnn");

    if (dotsss.style.display === "none") {
        dotsss.style.display = "inline";
        btnnnText.innerHTML = "Read more";
        moreeeText.style.display = "none";
    } else {
        dotsss.style.display = "none";
        btnnnText.innerHTML = "Read less";
        moreeeText.style.display = "inline";
    }
}

function myFunctionnnn() {
    var dotssss = document.getElementById("dotssss");
    var moreeeeText = document.getElementById("moreeee");
    var btnnnnText = document.getElementById("myBtnnnn");

    if (dotssss.style.display === "none") {
        dotssss.style.display = "inline";
        btnnnnText.innerHTML = "Read more";
        moreeeeText.style.display = "none";
    } else {
        dotssss.style.display = "none";
        btnnnnText.innerHTML = "Read less";
        moreeeeText.style.display = "inline";
    }
}

function myFunctionnnnn() {
    var dotsssss = document.getElementById("dotsssss");
    var moreeeeeText = document.getElementById("moreeeee");
    var btnnnnnText = document.getElementById("myBtnnnnn");

    if (dotsssss.style.display === "none") {
        dotsssss.style.display = "inline";
        btnnnnnText.innerHTML = "Read more";
        moreeeeeText.style.display = "none";
    } else {
        dotsssss.style.display = "none";
        btnnnnnText.innerHTML = "Read less";
        moreeeeeText.style.display = "inline";
    }
}